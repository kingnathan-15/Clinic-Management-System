from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.registerPage, name="register"),
    path('login/', views.loginPage, name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('patient/', views.patientPage, name="patient-page"),
    path('pharmacist/', views.pharmacistPage, name="pharmacist-page"),
    path('physician/', views.physicianPage, name="physician-page"),

    path('create_appointment/', views.createAppointment, name="create_Appointments"),
    path('', views.index, name="index"),
]