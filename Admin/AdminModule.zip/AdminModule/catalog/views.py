from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth import authenticate, login, logout

from django.contrib import messages

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group

# Create your views here.
from .models import *
from .forms import *
from .decorators import unauthenticated_user, allowed_users, admin_only


@unauthenticated_user
def registerPage(request):
    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            group = Group.objects.get(name='customer')
            user.groups.add(group)

            messages.success(request, 'Account was created for ' + username)

            return redirect('login')

    context = {'form': form}
    return render(request, 'register.html', context)


@unauthenticated_user
def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username OR password is incorrect')

    context = {}
    return render(request, 'login.html', context)


def logoutUser(request):
    logout(request)
    return redirect('login')


@login_required(login_url='login')
@admin_only
def index(request):

    num_appointments = Appointment.objects.count()

    context = {
        'num_appointments': num_appointments
    }

    return render(request, 'index.html', context=context)

def physicianPage(request):
    context = {}
    return render(request, 'physician.html', context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['Patients'])
def patientPage(request):
    #appointments = request.user.patient.appointment_set.all()
    #prescriptions = request.user.patient.prescription_set.all()
    context = {}
    return render(request, 'patients/patient.html', context)

def pharmacistPage(request):
    inventory = PharmacyInventory.objects.all()
    return render(request, 'pharmacist.html', {'inventory': inventory})

    pre = pre(request)
    if request.POST.get('action') == 'post':
        # get stuff
        Prescription_id = request.POST.get('Prescription_id')

        # delete funtion
        pre.delete(Prescription=Prescription_id)

        response = JsonResponse({'Prescription': Prescription_id})
        messages.success(request, ("Item deleted from pre"))
        return response

def createAppointment(request):
    return render(request, 'patients/appointment_form.html', context)

def createPrescription(request):
    return render(request)